#CheatMod By Kristof1104	

This is a mod for Game Dev Tycoon, it enables users to use cheats through an in-game menu.
Using this mod is a safer method then changing the save game directly with an editor.

version 0.1.1
Features:
    - Add Money
	- Add ResearchPoints
    - Add Fans
    - Add DreamTeam (Fills in all open team spots with pro-level Game-designers)
	
version 0.1.2
New Features:
    - Goto last level of Game Dev tycoon (Hardware and RnD lab included)

version 0.1.3
New Features:
    - Add AAA research
	
	
How to add CheatMod to your Game Dev Tycoon:

	

    First of all you need to have the beta version of Game Dev Tycoon on steam. 
	To do so:
        -Go to your Steam library
        -Right-click on Game Dev Tycoon
        -Select properties
        -Go to the 'BETA's' tab
        -Select 'Beta - beta' from the list
		
		
	Next download the latest version of Cheatmod normally cheatmod.zip on Github.
	
    Now you have to go to you steamapps folder  (STEAM INSTALL PATH) /steamapps/common/Game Dev Tycoon/mods

    Paste the Cheatmod folder in the mods folder
	
	Now startup the game and open the main menu.
	In the main menu open up the mods screen.
	Select Cheatmod and reboot Game Dev Tycoon.
	
Now when you press the left mouse button a new option called "cheatmode..." is added.

That's it :)
For questions or feedback
send me(Kristof1104) a message at http://forum.greenheartgames.com

	