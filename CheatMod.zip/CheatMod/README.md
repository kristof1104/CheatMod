#CheatMod By Kristof1104	

This is a mod for Game Dev Tycoon, it enables users to use cheats through an in-game menu.
Using this mod is a safer method then changing the save game directly with an editor.

version 0.1.1
Features:
    - Add Money
	- Add ResearchPoints
    - Add Fans
    - Add DreamTeam (Fills in all open team spots with pro-level Game-designers)
	
version 0.1.2
New Features:
    - Goto last level of Game Dev tycoon (Hardware and RnD lab included)

version 0.1.3
New Features:
    - Add AAA research
	
version 0.1.4
New Features:
    - Move in Time function, you can now goto any year in the game
	
version 0.1.5
Bug-fix:
    - Fixed bug in version 0.1.4 (when adding money an debug alert was displayed)
		
version 0.1.6
New Features:
    - Money can now be added By 1M, 10M, 20M.
	- Staff members don't need Vacation.
	
version 0.1.7
BugFix:
	- Works with latest Game Dev Tycoon Version
	
version 0.1.8
New Features:
    - Hype can now be added by 100 points.
	- Always perfect games mode added.

version 0.1.9
New Features:
    - Added A No Bugs Mode (No bugs during game creation)
	- Add All Topics (Research All Topics)
	
version 0.2.0
BugFixes:
	- Fixed a problem with the No Bugs Mode
New Features:
    - Added Fast Research Mode (Research is almost instant)
	
version 0.2.1
	- Female staff members added tot 1337 dreamTeam.	
	
version 0.2.2
	- Fixed bug in Fast Reseach Mode, Training staff now works again.
	- Added Feature to give yourself Pro developing skills.
	- Added Feature to create Random strong trends!
	- Random 11 out of 10 scores now possible in "Always perfect games mode".
	- Add hype by 10 , 50 and 100
	- Add Fans by 1M , 10M and 100M
version 0.2.3
	- Fixed bug in Add DreamTeam, (sometimes in level 4 it wouldn't add the last 2 staff members)
version 0.3.0
	- Added Feature ,Users can now add Tech levels ( For example Graphics V3 lvl 15 ..)
	- Added Feature to allow users to add Design & Tech points to a game during game development
version 1.0.0
	- Added Feature To Add Sequel games
	- Added Feature To allow users to add Design & Tech points by 10 or 100
	- Added Feature To allow players to easily add ResearchPoints by a + button.
	- Added Boost L2 for DreamTeam
	- Added Feature To add a B-Team: stats are at 700 instead of 1000.
version 1.0.1
	- Added Feature To Add 1B Money
version 1.0.2
	- Added Feature To Show/Unlock All hints
version 1.0.3
	- Bugfix Show/Unlock All hints

	
How to add CheatMod to your Game Dev Tycoon:

	

    First of all you need to have the beta version of Game Dev Tycoon on steam. 
	To do so:
        -Go to your Steam library
        -Right-click on Game Dev Tycoon
        -Select properties
        -Go to the 'BETA's' tab
        -Select 'Beta - beta' from the list
		
		
	Next download the latest version of Cheatmod normally cheatmod.zip on Github.
	
    Now you have to go to you steamapps folder  (STEAM INSTALL PATH) /steamapps/common/Game Dev Tycoon/mods

    Paste the Cheatmod folder in the mods folder
	
	Now startup the game and open the main menu.
	In the main menu open up the mods screen.
	Select Cheatmod and reboot Game Dev Tycoon.
	
Now when you press the left mouse button a new option called "cheatmode..." is added.

That's it :)
For questions or feedback
send me(Kristof1104) a message at http://forum.greenheartgames.com

	