﻿(function () {
	var ready = function () {
	};

	var error = function () {
	};

	GDT.loadJs(['mods/CheatMod/source/source.js'], ready, error);
})();